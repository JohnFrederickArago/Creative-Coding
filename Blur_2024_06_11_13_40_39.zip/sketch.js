let img;

function preload() {
  img = loadImage('bp-miller-rGDv4llw-mk-unsplash.jpg');
}

function setup() {
  createCanvas(800, 800);
  image(img, 0, 0, width, height);
  filter(BLUR, 10);
}
