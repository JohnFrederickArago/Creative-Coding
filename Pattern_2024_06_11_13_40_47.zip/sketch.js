function setup() {
  createCanvas(800, 800);
  background('#E8DFCA');
  noFill();
  stroke('#4F6F52'); 
  strokeWeight(5);

  // Draw ellipses in a grid pattern
  let xStart = (width % 50) / 2;
  let yStart = (height % 50) / 2;
  for (let i = xStart; i <= width - xStart; i += 50) {
    for (let j = yStart; j <= height - yStart; j += 50) {
      ellipse(i, j, 30, 30);
    }
  }
}