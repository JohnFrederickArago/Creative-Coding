function setup() {
  createCanvas(800, 800);
  background('#F9F9E0'); 

  fill('#F8C794'); 
  triangle(300, 500, 500, 500, 400, 800); 

  stroke('#D8AE7E'); 
  strokeWeight(2); 

  line(350, 500, 335, 600);
  line(370, 500, 345, 630);
  line(390, 500, 355, 660);
  line(410, 500, 365, 690);
  line(430, 500, 375, 720);
  line(450, 500, 385, 750);
  line(470, 500, 395, 785);

  fill('#FF9EAA');
  ellipse(400, 425, 250, 250);

  fill('#EE4E4E'); 
  ellipse(400, 300, 100, 100);
  line(420, 200, 400, 250);
  
  fill('#3AA6B9'); 
  ellipse(400 - 46, 425 - 75, 15, 15);
  ellipse(400 + 12, 425 - 50, 15, 15);
  ellipse(400 + 50, 425 - 20, 15, 15);

  fill('#FFD0D0'); 
  ellipse(400 - 20, 425 - 50, 15, 15);
  ellipse(400 - 10, 425 - 20, 15, 15);
  ellipse(400 + 45, 425 - 50, 15, 15);
}
