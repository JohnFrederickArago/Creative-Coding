var word = 'Hello World';
var font1;

function preload() {
  font1 = loadFont('Blantick Script.ttf');
}


function setup() {
  createCanvas(800, 800);
  background('#F6E9B2');
  fill('#0A6847');
  textFont(font1, 100);
  textAlign(CENTER);
  text(word, width/2, height/2);
}