function setup() {
  createCanvas(800, 800);
}

function draw() {
  background('gray')
  
  fill('#444444')
  rect(0, 200, 2000, 100)
  
  fill('brown')
  rect(88, 100, 25, 100)
  rect(288, 100, 25, 100)
  
  
  fill('green')
  ellipse(100, 100, 70)
  ellipse(300, 100, 70)
  
  fill('yellow')
  rect(mouseX, mouseY, 100, 50);
  rect(mouseX+100, mouseY, 100, 50);
  triangle(mouseX, mouseY, mouseX+100, mouseY, mouseX+50,         mouseY-50)
  triangle(mouseX+100, mouseY, mouseX+200, mouseY, mouseX+150,     mouseY-50)
  triangle(mouseX+100, mouseY, mouseX+150, mouseY-50, mouseX+50,   mouseY-50)
  rect(mouseX+90, mouseY-60, 20, 10)
  
  fill('black')
  ellipse(mouseX+40, mouseY+50, 60)
  ellipse(mouseX+160, mouseY+50, 60)
  rect(mouseX+65, mouseY+10, 10, 5)
  rect(mouseX+145, mouseY+10, 10, 5)
  
  fill('white')
  ellipse(mouseX+40, mouseY+50, 40)
  ellipse(mouseX+160, mouseY+50, 40)
  
  fill('white')
  rect(mouseX, mouseY+10, 20, 10)
  
  fill('#abd4f8')
  triangle(mouseX+15, mouseY-5, mouseX+65, mouseY-5,               mouseX+65,   mouseY-45)
  rect(mouseX+75, mouseY-43, 50, 38)
  triangle(mouseX+135, mouseY-5, mouseX+185, mouseY-5,             mouseX+135, mouseY-45)
  
  fill('#29272d')
  rect(mouseX+196, mouseY+35, 13, 10)
  
  fill('red')
  ellipse(mouseX+200, mouseY+17, 20)
}