var numbers = [ 30, 100, 75, 55, 20, 38, 89, 67 ];

function setup() {
  createCanvas(800, 800);
  background('#F3F7EC');
  colorMode(HSL, 100);
  noStroke();
  
  var diameter = 700;
  var lastAngle= 0; 

  for (var i= 0; i< numbers.length; i++) {
    var n = numbers[i];
    var c = map(n, 0, max(numbers), 0, 100);
    fill(0, 100, c);
    arc(width/2, height/2, diameter, diameter, lastAngle, lastAngle+radians(n));
    lastAngle+= radians(n);
  }
}