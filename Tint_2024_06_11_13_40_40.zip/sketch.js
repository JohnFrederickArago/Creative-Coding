let img;

function preload() {
  img = loadImage('craig-bradford-65rKP9bhTDQ-unsplash.jpg');
}

function setup() {
  createCanvas(800, 800);
  tint('#BACD92');
  image(img, 0, 0, width, height);
}
