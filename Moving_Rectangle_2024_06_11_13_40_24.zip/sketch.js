class Rectangle {
  constructor(x, y, w, h, color) {
    this.x = x; 
    this.y = y; 
    this.w = w; 
    this.h = h; 
    this.color = color 
  }

  display() {
    fill(this.color);
    rect(this.x, this.y, this.w, this.h);
  }

  move(dx, dy) {
    this.x += dx;
    this.y += dy;
  }
}

let rect1; 

function setup() {
  createCanvas(400, 400);
  
  rect1 = new Rectangle(50, 50, 100, 80, color(255, 0, 0));
}

function draw() {
  background(220);
  
  rect1.display();
}

function keyPressed() {
  if (keyCode === LEFT_ARROW) {
    rect1.move(-10, 0);
  } else if (keyCode === RIGHT_ARROW) {
    rect1.move(10, 0);
  } else if (keyCode === UP_ARROW) {
    rect1.move(0, -10);
  } else if (keyCode === DOWN_ARROW) {
    rect1.move(0, 10)
  }
}
