let img;

function preload() {
  img = loadImage('jessica-radanavong-mrYkTuAesKE-unsplash.jpg'); 
}

function setup() {
  createCanvas(800, 800);
  image(img, 0, 0, width, height); 
  filter(INVERT); 
}
