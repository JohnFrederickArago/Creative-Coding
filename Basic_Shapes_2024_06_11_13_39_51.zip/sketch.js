function setup() {
  createCanvas(400, 400);
  background('#1A4D2E'); 
}

function draw() {
  stroke('#4F6F52');
  strokeWeight(4);
  
  fill('#E8DFCA');
  rect(25, 175, 100, 50);
  
  fill('#E8DFCA');
  ellipse(200, 200, 80, 80);

  fill('#E8DFCA');
  triangle(270, 240, 320, 170, 370, 240);
}
