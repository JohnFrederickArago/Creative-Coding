let sound, vol;
let xspacing = 5;    // Distance between each horizontal location
let w;                // Width of entire wave
let theta = 0.0;      // Start angle at 0
let amplitude = 200; // Height of wave
let period = 300.0;   // How many pixels before the wave repeats
let dx;               // Value for incrementing x
let yvalues;  // Using an array to store height values for the wave

function preload() {
    sound = loadSound("Tahiti.mp3");
}

function setup() {
    sound.play();
    vol = new p5.Amplitude();
    createCanvas(1280, 720);
    w = width + 16;
    dx = (TWO_PI / period) * xspacing;
    yvalues = new Array(floor(w / xspacing));
}

function draw() {
    background(0);
    let level = vol.getLevel();
    calcWave(level);
    renderWave();
    drawBackground();
}

function calcWave(level) {
    let x = theta;
    for (let i = 0; i < yvalues.length; i++) {
        yvalues[i] = sin(x) * amplitude * level;
        x += dx;
    }
}

function renderWave() {
    noStroke();
    for (let x = 0; x < yvalues.length; x++) {
        fill('white');
        ellipse(x * xspacing, height / 2 + yvalues[x], 8, 8);
    }
}

function drawBackground() {
    let r1 = map(sin(frameCount * 0.01), -1, 1, 0, 255);
    let g1 = map(cos(frameCount * 0.01), -1, 1, 0, 255);
    let b1 = map(sin(frameCount * 0.01), -1, 1, 255, 0);
    let r2 = map(cos(frameCount * 0.01), -1, 1, 0, 255);
    let g2 = map(sin(frameCount * 0.01), -1, 1, 255, 0);
    let b2 = map(cos(frameCount * 0.01), -1, 1, 0, 255);
    setGradient(0, 0, width, height, color(r1, g1, b1), color(r2, g2, b2));
}

function setGradient(x, y, w, h, c1, c2) {
    noFill();
    for (let i = y; i <= y + h; i++) {
        let inter = map(i, y, y + h, 0, 1);
        let c = lerpColor(c1, c2, inter);
        stroke(c);
        line(x, i, x + w, i);
    }
}