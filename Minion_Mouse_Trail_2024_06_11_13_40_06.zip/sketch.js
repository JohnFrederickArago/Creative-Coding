function setup() {
  createCanvas(800, 800);
  background('white')
}

function draw() {
  fill('yellow')
  ellipse(mouseX, mouseY,80)
  rect(mouseX-40, mouseY, 80, 100)
  
  fill('#bcbcbc')
  ellipse(mouseX, mouseY, 40)
  
  fill('yellow')
  ellipse(mouseX, mouseY, 30)
  
  fill('white')
  ellipse(mouseX, mouseY, 20)
  
  fill('brown')
  ellipse(mouseX, mouseY, 10)
  
  fill('blue')
  rect(mouseX-25, mouseY+40, 50, 60)
  rect(mouseX-40, mouseY+40, 20, 10)
  rect(mouseX+20, mouseY+40, 20, 10)
}

function mousePressed(){
  background('white')
}