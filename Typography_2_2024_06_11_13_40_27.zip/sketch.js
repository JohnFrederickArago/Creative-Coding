let font;
let points;

function preload() {
  font = loadFont('Blantick Script.otf');
}

function setup() {
  createCanvas(600, 600);
  stroke('#0A6847');
  textSize(150);
  
  let calculatedTextWidth = textWidth('welcome');
  let textHeight = textAscent() + textDescent();

  let x = (width - calculatedTextWidth) / 2 + 100; 
  let y = (height + textHeight) / 2 - textDescent() - 30;
  
  points = font.textToPoints('welcome', x, y, 200, {sampleFactor: 0.15}); 
  
  background('#F6E9B2');
  
  for (let i = 0; i < points.length; i++) {
    let p = points[i];
    ellipse(p.x, p.y, 3, 3);
  }
}
