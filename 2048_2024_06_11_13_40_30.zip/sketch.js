let board;

function setup() {
  createCanvas(500, 500);
  board = [
    [0, 0, 0, 0],
    [0, 0, 0, 0],
    [0, 0, 0, 0],
    [0, 0, 0, 0]
  ];
  addNumber();
  addNumber();
}

function draw() {
  background(255);
  drawBoard();
  
  if (isGameOver()) {
    fill(255, 0, 0);
    textSize(40);
    textAlign(CENTER, CENTER);
    text("Game Over!", width / 2, height / 2);
  }
}

function keyPressed() {
  if (keyCode === LEFT_ARROW) {
    moveLeft();
  } else if (keyCode === RIGHT_ARROW) {
    moveRight();
  } else if (keyCode === UP_ARROW) {
    moveUp();
  } else if (keyCode === DOWN_ARROW) {
    moveDown();
  }
}

function drawBoard() {
  for (let i = 0; i < 4; i++) {
    for (let j = 0; j < 4; j++) {
      let value = board[i][j];
      let x = i * 100 + 50;
      let y = j * 100 + 50;
      fill(255);
      rect(x, y, 100, 100);
      if (value !== 0) {
        textAlign(CENTER, CENTER);
        textSize(32);
        fill(0);
        text(value, x + 50, y + 50);
      }
    }
  }
}

function addNumber() {
  let options = [];
  for (let i = 0; i < 4; i++) {
    for (let j = 0; j < 4; j++) {
      if (board[i][j] === 0) {
        options.push({ x: i, y: j });
      }
    }
  }
  if (options.length > 0) {
    let spot = random(options);
    let r = random(1);
    board[spot.x][spot.y] = r > 0.5 ? 2 : 4;
  }
}

function moveLeft() {
  for (let j = 0; j < 4; j++) {
    for (let i = 1; i < 4; i++) {
      if (board[i][j] !== 0) {
        let value = board[i][j];
        let k = i - 1;
        while (k >= 0 && (board[k][j] === 0 || board[k][j] === value)) {
          if (board[k][j] === value) {
            board[k][j] *= 2;
            board[i][j] = 0;
            break;
          } else if (board[k][j] === 0) {
            board[k][j] = value;
            board[i][j] = 0;
          }
          k--;
        }
      }
    }
  }
  addNumber();
}

function moveRight() {
  for (let j = 0; j < 4; j++) {
    for (let i = 2; i >= 0; i--) {
      if (board[i][j] !== 0) {
        let value = board[i][j];
        let k = i + 1;
        while (k < 4 && (board[k][j] === 0 || board[k][j] === value)) {
          if (board[k][j] === value) {
            board[k][j] *= 2;
            board[i][j] = 0;
            break;
          } else if (board[k][j] === 0) {
            board[k][j] = value;
            board[i][j] = 0;
          }
          k++;
        }
      }
    }
  }
  addNumber();
}

function moveUp() {
  for (let i = 0; i < 4; i++) {
    for (let j = 1; j < 4; j++) {
      if (board[i][j] !== 0) {
        let value = board[i][j];
        let k = j - 1;
        while (k >= 0 && (board[i][k] === 0 || board[i][k] === value)) {
          if (board[i][k] === value) {
            board[i][k] *= 2;
            board[i][j] = 0;
            break;
          } else if (board[i][k] === 0) {
            board[i][k] = value;
            board[i][j] = 0;
          }
          k--;
        }
      }
    }
  }
  addNumber();
}

function moveDown() {
  for (let i = 0; i < 4; i++) {
    for (let j = 2; j >= 0; j--) {
      if (board[i][j] !== 0) {
        let value = board[i][j];
        let k = j + 1;
        while (k < 4 && (board[i][k] === 0 || board[i][k] === value)) {
          if (board[i][k] === value) {
            board[i][k] *= 2;
            board[i][j] = 0;
            break;
          } else if (board[i][k] === 0) {
            board[i][k] = value;
            board[i][j] = 0;
          }
          k++;
        }
      }
    }
  }
  addNumber();
}

function isGameOver() {
  // Check if game is over
  for (let i = 0; i < 4; i++) {
    for (let j = 0; j < 4; j++) {
      if (board[i][j] === 0) {
        return false; // Empty cell found
      }
      if (i !== 3 && board[i][j] === board[i + 1][j]) {
        return false; // Check adjacent cells horizontally
      }
      if (j !== 3 && board[i][j] === board[i][j + 1]) {
        return false; // Check adjacent cells vertically
      }
    }
  }
  return true; // No available moves left
}
