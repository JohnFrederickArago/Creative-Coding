var numbers = [100, 300, 500, 700, 900, 900, 700, 500, 300, 100]

function setup() {
  createCanvas(800, 800);
  background(0)
  for (var i = 0; i < numbers.length; i++) {
    var n = numbers[i];
    fill(n, 850, 900);
    rect(i*80, height-n, 80, n);
  }
}