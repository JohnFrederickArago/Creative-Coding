let img;

function preload() {
  img = loadImage('paul-kansonkho-1ZjvDbug1gY-unsplash.jpg'); 
}

function setup() {
  createCanvas(800, 800);
  image(img, 0, 0, width, height); 
  filter(THRESHOLD, 0.5);
}
